# AMZ SHOP - Asif Mobile Zone 📱⚡

A high-performance Progressive Web Application (PWA) and mobile tool designed for **AMZ SHOP** (Asif Mobile Zone, KPK Bannu, Pakistan). This app allows users and retailers to browse, search, and activate **Ufone** and **Jazz** packages with 1-click USSD dialing, send instant Easyload, and process Load Reversals. Featuring a built-in luxury AMZ SHOP animated splash screen, offline caching, and PWA mobile installation.

---

## 🚀 Key Features

- **🛍️ AMZ SHOP Branding & Splash Screen**: Fast animated startup splash screen with tap-to-skip.
- **✨ Professional Midnight Titanium Theme**: Deep executive dark palette without harsh bright orange blocks.
- **📶 Dual Network Support**: Seamless toggle between **Ufone 4G** and **Jazz 4G** networks.
- **⚡ Instant 1-Click USSD Dialing**: Automatically formats and dials USSD codes (`*...*number#`) in the phone dialer without stripping `#`.
- **📋 Automatic Clipboard Copy**: Copies the full USSD code so users can paste directly if any dialer app modifies the string.
- **📲 Progressive Web App (PWA)**: Installable directly onto Android & iOS home screens. Works offline with fast asset caching.
- **💸 Dual Easyload & Load Reversal Tools**:
  - **Ufone Easyload**: `*777*number*amount*111111#`
  - **Ufone Load Reverse**: `*964*number*10*3*TID#`
  - **Jazz Easyload**: `*510*1*number*Rs#`
  - **Jazz Load Reverse**: `*510*4*Trx id#` (Flexible 11 to 20+ digits TID)
- **🔍 Instant Live Search & Filter Chips**: Filter packages by Gaming, Social, Internet Data, or Calls.

---

## 🛠️ How to Push to GitHub

Follow these simple steps in your terminal to create and publish this app on GitHub:

```bash
# 1. Initialize git repository
git init

# 2. Stage all files
git add .

# 3. Commit changes
git commit -m "feat: AMZ SHOP with Ufone & Jazz Easyload, Load Reversal and updated packages"

# 4. Set main branch
git branch -M main

# 5. Connect to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/amz-shop.git

# 6. Push to GitHub
git push -u origin main
```

---

## 📦 How to Run Locally

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📱 How to Convert to an Android APK

### Option 1: PWABuilder (Fastest & Free — No Coding Needed)
1. Deploy your app to Vercel, Netlify, or GitHub Pages.
2. Go to [PWABuilder.com](https://www.pwabuilder.com).
3. Enter your deployed URL and click **Start**.
4. Click **Package for Android** to download the signed APK or Google Play Store AAB package.

### Option 2: Capacitor (Native Android Studio Project)
```bash
# 1. Install Capacitor
npm install @capacitor/core
npm install -D @capacitor/cli @capacitor/android

# 2. Initialize Capacitor
npx cap init "AMZ SHOP" "com.amzshop.app" --web-dir dist

# 3. Build Vite app
npm run build

# 4. Add Android platform
npx cap add android

# 5. Open in Android Studio to build APK
npx cap open android
```

---

## 📁 Where to Change Prices & Codes (Folder Structure)

All package prices, USSD codes, features, and logos are located in:
👉 **`src/constants.ts`**

Each package is defined using this structure:
```typescript
{
  id: 'u-w-upower-350',
  title: 'UPOWER Weekly',
  price: 350,                                      // Change price here
  features: ['4GB Data', '5000 u2u minutes'],     // Change features here
  ussd: '*4000*3*number#',                        // Change USSD code here (keep 'number')
  logo: 'https://...',                            // Package logo link
  category: 'weekly',                             // 'weekly' or 'monthly'
  network: 'ufone'                                // 'ufone' or 'jazz'
}
```

---

## 📋 Current Active Package List

### 🟢 Ufone Weekly Packages
| Title | Price | Features | USSD Code |
|---|---|---|---|
| **TikTok Offer** | Rs 120 | 4GB Data TikTok, 7 Days | `*1010*number#` |
| **FreeFire Offer** | Rs 60 | 1GB General + 4GB FreeFire | `*9090*2*2*number#` |
| **PUBG Offer** | Rs 70 | Gaming Data, 7 Days | `*9090*1*2*number#` |
| **UPOWER Weekly** | Rs 350 | 4GB Data, 5000 u2u, 100 off-net | `*4000*3*number#` |
| **UPOWER Weekly** | Rs 450 | 10GB Data, 5000 u2u, 200 off-net | `*4000*2*number#` |
| **Weekly Internet** | Rs 500 | 15GB Data, 5000 u2u, 300 off-net | `*4000*1*number#` |
| **Weekly Internet 60GB** | Rs 600 | 60GB Data, 5000 u2u, 600 off-net | `*4040*3*number#` |
| **25GB Weekly Offer** | Rs 550 | 25GB Data, 5000 u2u, 250 off-net | `*4000*5*number#` |
| **Super Recharge** | Rs 120 | 500MB Data, 200 u2u, 20 off-net, 2 Days | `*4000*7*number#` |
| **100GB Offer** | Rs 630 | 100GB Data, 5000 u2u, 300 off-net | `*4040*2*number#` |
| **150GB Offer** | Rs 680 | 150GB Data, 5000 u2u, 300 off-net | `*4040*1*number#` |

### 🟢 Ufone Monthly Packages
| Title | Price | Features | USSD Code |
|---|---|---|---|
| **FreeFire Monthly** | Rs 100 | 1GB General + 9GB FreeFire, 30 Days | `*9090*2*3*number#` |
| **PUBG Monthly** | Rs 150 | 1GB General + 9GB PUBG, 30 Days | `*9090*1*3*number#` |
| **25GB Social + Calls** | Rs 800 | 25GB Data, 3000 u2u, 300 off-net | `*964*number*3*1*1#` |
| **WhatsApp Monthly** | Rs 300 | 10GB WhatsApp Data, 30 Days | `*964*number*3*1*3#` |
| **Mahana Awaz Offer** | Rs 650 | 4000 u2u, 400 off-net, 30 Days | `*964*number*6*2*4#` |
| **SnapChat Offer** | Rs 90 | 6GB Snapchat Data, 30 Days | `*5550*5*number#` |

### 🔴 Jazz Weekly Packages
| Title | Price | Features | USSD Code |
|---|---|---|---|
| **Weekly PUBG** | Rs 70 | PUBG Data, 7 Days Validity | `*964*number*3*2*2#` |
| **Weekly Super Card** | Rs 250 | 3GB + 10GB WA, 300 Jazz, 10 AllNet | `*964*number*5*7*7#` |
| **Weekly Mega Data** | Rs 300 | 5GB Data, 1000 Jazz, 50 Off-Net | `*964*number*5*7*5#` |
| **Weekly X Plus** | Rs 800 | 100GB Data, 2000 Jazz, 600 Off-Net | `*964*number*1*2*1#` |
| **Weekly Freedom** | Rs 750 | 50GB Data, 1000 Jazz, 3300 AllNet | `*964*number*1*2*2#` |
| **Weekly Max** | Rs 700 | 30GB Data, 1000 Jazz, 150 AllNet | `*964*number*1*2*3#` |
| **Weekly Star** | Rs 650 | 20GB Data, 1000 Jazz, 150 AllNet | `*964*number*1*2*4#` |
| **Weekly Woman Bundle**| Rs 250 | 12GB Data (8 AM - 6 PM), 1000 Jazz | `*964*number*1*2*9#` |

### 🔴 Jazz Monthly Packages
| Title | Price | Features | USSD Code |
|---|---|---|---|
| **Monthly X** | Rs 3100 | 200GB Data, 3000 Jazz, 1000 AllNet | `*964*number*1*1*1#` |
| **Monthly Social** | Rs 1700 | 50GB Data TikTok/Social, 3000 Jazz | `*964*number*3*1*2#` |
| **Monthly Social Pack**| Rs 1500 | 30GB Social + TikTok, 500 Jazz, 100 Off | `*964*number*3*1*3#` |
| **Monthly Social** | Rs 1200 | 20GB Social + TikTok, 500 Jazz | `*964*number*3*1*4#` |
| **Monthly Ultra Social**| Rs 700 | 10GB YT & Social, 300 Jazz, 50 AllNet | `*964*number*3*1*7#` |
| **Monthly WhatsApp** | Rs 550 | 10GB Social Data, 300 Jazz, 15 OffNet | `*964*number*3*1*8#` |
| **Monthly Call** | Rs 900 | 2000 Jazz Minutes, 300 Off-Net | `*964*number*4*1*4#` |
| **Monthly Gaming Pack**| Rs 500 | Gaming Optimized Data, 1000 Jazz | `*964*number*4*1*5#` |

---

## 👨‍💻 Developer & Credits

- **Application**: ASIF MOBILE ZONE
- **Developer**: FAISAL MALIK
- **WhatsApp Support**: +92 333 3808084
- **Location**: KPK Bannu, Pakistan
