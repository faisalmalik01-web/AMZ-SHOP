import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, ShieldCheck, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 300);
          return 100;
        }
        return prev + 12;
      });
    }, 90);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ duration: 0.45, ease: 'easeInOut' }}
      onClick={onComplete}
      className="fixed inset-0 z-[9999] bg-slate-950 flex flex-col items-center justify-between p-8 select-none cursor-pointer overflow-hidden"
    >
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl pointer-events-none" />

      {/* Top Tag */}
      <div className="w-full flex justify-between items-center text-xs text-slate-500 pt-2">
        <span className="font-mono text-[10px] tracking-wider uppercase">v2.5 • Official Portal</span>
        <span className="text-[10px] text-slate-400 font-semibold bg-slate-900 border border-slate-800 px-2 py-0.5 rounded-full">
          Tap to skip
        </span>
      </div>

      {/* Center Brand Identity */}
      <div className="flex flex-col items-center text-center my-auto">
        {/* Animated AMZ Emblem */}
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          className="relative mb-6"
        >
          {/* Outer glow ring */}
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-gradient-to-tr from-amber-500/20 via-orange-500/20 to-rose-500/20 p-[2px] shadow-2xl shadow-amber-500/20">
            <div className="w-full h-full rounded-3xl bg-slate-900/90 backdrop-blur-xl border border-slate-700/60 flex flex-col items-center justify-center relative overflow-hidden">
              {/* Subtle background light */}
              <div className="absolute inset-0 bg-gradient-to-b from-amber-500/10 to-transparent" />
              
              <span className="font-display font-black text-2xl sm:text-3xl tracking-wider bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400 bg-clip-text text-transparent">
                AMZ
              </span>
              <span className="text-[9px] font-black tracking-widest uppercase px-2 py-0.5 mt-0.5 rounded-full bg-slate-800 text-amber-300 border border-amber-500/30">
                SHOP
              </span>
            </div>
          </div>

          {/* Floating Sparkle Badge */}
          <motion.div 
            animate={{ rotate: [0, 15, -15, 0] }}
            transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
            className="absolute -top-1.5 -right-1.5 w-6 h-6 rounded-full bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-lg shadow-amber-500/30"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </motion.div>
        </motion.div>

        {/* Brand Name & Tagline */}
        <motion.div
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.4 }}
        >
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white font-display mb-1.5 flex items-center justify-center gap-2">
            <span>AMZ SHOP</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20">
              PRO
            </span>
          </h1>
          <p className="text-xs text-slate-400 max-w-[260px] leading-relaxed">
            Pak Telecom Packages, USSD Dialing & Instant Easyload
          </p>
        </motion.div>

        {/* Network Badges in Splash */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35, duration: 0.4 }}
          className="flex items-center gap-2 mt-5 text-[10px] font-bold"
        >
          <span className="px-2.5 py-1 rounded-lg bg-orange-500/15 text-orange-400 border border-orange-500/30 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse" />
            UFONE 4G
          </span>
          <span className="px-2.5 py-1 rounded-lg bg-rose-500/15 text-rose-400 border border-rose-500/30 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
            JAZZ 4G
          </span>
        </motion.div>
      </div>

      {/* Bottom Loading Progress Bar */}
      <div className="w-full max-w-xs flex flex-col items-center gap-2.5 pb-2">
        <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800 p-[1px]">
          <motion.div 
            className="h-full bg-gradient-to-r from-amber-400 via-orange-500 to-rose-500 rounded-full"
            style={{ width: `${progress}%` }}
            transition={{ duration: 0.1 }}
          />
        </div>
        <div className="flex justify-between w-full text-[10px] text-slate-500 font-mono">
          <span>Loading packages & USSD...</span>
          <span>{progress}%</span>
        </div>

        <div className="flex items-center gap-1.5 text-[10px] text-slate-600 mt-2">
          <ShieldCheck className="w-3 h-3 text-slate-500" />
          <span>ASIF MOBILE ZONE • BANNU KPK</span>
        </div>
      </div>
    </motion.div>
  );
};
