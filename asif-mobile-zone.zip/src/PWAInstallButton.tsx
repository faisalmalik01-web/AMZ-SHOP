import React, { useState } from 'react';
import { Download, Share2, PlusSquare, X } from 'lucide-react';
import { usePWAInstall } from './usePWAInstall';

interface PWAInstallButtonProps {
  isDark?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ isDark = true }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  const buttonClasses = `flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all active:scale-95 shadow-xs border ${
    isDark
      ? 'bg-white/10 hover:bg-white/20 text-white border-white/20'
      : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
  }`;

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className={buttonClasses}
        title="Install Application on your phone"
      >
        <Download className="w-3 h-3" />
        <span>Install App</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className={buttonClasses}
          title="Install on iPhone / iPad"
        >
          <Download className="w-3 h-3" />
          <span>Install App</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <div className="w-full max-w-xs rounded-2xl bg-white p-5 shadow-2xl relative text-slate-800 animate-in fade-in zoom-in-95 duration-200">
              <button 
                onClick={() => setShowIOSGuide(false)}
                className="absolute right-3 top-3 p-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500"
              >
                <X className="w-4 h-4" />
              </button>
              
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-900">Install Asif Mobile</h3>
                  <p className="text-[10px] text-slate-500">iPhone / iPad Setup</p>
                </div>
              </div>

              <div className="space-y-2 text-[11px] text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-100 mb-4">
                <div className="flex items-start gap-2">
                  <Share2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span>1. Tap the <strong>Share</strong> button in Safari toolbar.</span>
                </div>
                <div className="flex items-start gap-2">
                  <PlusSquare className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <span>2. Scroll down & select <strong>Add to Home Screen</strong>.</span>
                </div>
              </div>

              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-full rounded-xl bg-slate-900 py-2 text-xs font-bold text-white hover:bg-slate-800 transition"
              >
                Got it / سمجھ آگیا
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
