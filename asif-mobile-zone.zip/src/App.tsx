/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { memo, useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  Smartphone, 
  Phone, 
  Zap, 
  Calendar, 
  MessageCircle, 
  CheckCircle2, 
  X, 
  ChevronRight, 
  Info, 
  Copy, 
  Check, 
  Gamepad2, 
  Globe, 
  Sparkles, 
  ShieldCheck, 
  RotateCcw, 
  BadgePercent,
  Sun,
  Moon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PACKAGES, type Package } from './constants';
import { PWAInstallButton } from './PWAInstallButton';
import { OfflineIndicator } from './OfflineIndicator';
import { SplashScreen } from './SplashScreen';

type Network = 'ufone' | 'jazz';
type Category = 'weekly' | 'monthly';
type FilterTag = 'all' | 'data' | 'social' | 'gaming' | 'calls';

// Feature Item with clean contextual icon
const FeatureItem = memo(({ text, network, isDark }: { text: string; network: Network; isDark: boolean }) => {
  const isJazz = network === 'jazz';
  const isData = /gb|mb|data|internet/i.test(text);
  const isCall = /minute|min|call|off-net|u2u|jazz/i.test(text);
  const isSocial = /whatsapp|tiktok|snapchat|fb|social/i.test(text);
  const isGaming = /gaming|game|freefire|pubg/i.test(text);

  return (
    <li className={`flex items-center gap-2 text-[12px] font-medium transition-colors ${
      isDark ? 'text-slate-300' : 'text-slate-700'
    }`}>
      <span className={`w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 ${
        isGaming ? (isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700') :
        isSocial ? (isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700') :
        isData ? (isDark ? 'bg-cyan-500/20 text-cyan-400' : 'bg-blue-100 text-blue-700') :
        isCall ? (isDark ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-100 text-indigo-700') :
        isJazz ? (isDark ? 'bg-rose-500/20 text-rose-400' : 'bg-rose-100 text-rose-700') : 
        (isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700')
      }`}>
        {isGaming ? <Gamepad2 className="w-2.5 h-2.5" /> :
         isSocial ? <MessageCircle className="w-2.5 h-2.5" /> :
         isData ? <Globe className="w-2.5 h-2.5" /> :
         isCall ? <Phone className="w-2.5 h-2.5" /> :
         <Check className="w-2.5 h-2.5 stroke-[3]" />}
      </span>
      <span className="leading-snug">{text}</span>
    </li>
  );
});
FeatureItem.displayName = 'FeatureItem';

// High-end Redesigned PackageCard (Adapts cleanly to Luxury Dark & Crisp Executive Light)
const PackageCard = memo(({ 
  pkg, 
  onActivate, 
  onQuickCopy, 
  isCopied,
  isDark
}: { 
  pkg: Package; 
  onActivate: (pkg: Package) => void;
  onQuickCopy: (ussd: string) => void;
  isCopied: boolean;
  isDark: boolean;
}) => {
  const isJazz = pkg.network === 'jazz';
  const isWeekly = pkg.category === 'weekly';

  return (
    <motion.div 
      layout="position"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.2 }}
      className={`group relative rounded-2xl border transition-all duration-300 flex flex-col justify-between overflow-hidden ${
        isDark
          ? `bg-slate-900/90 backdrop-blur-md shadow-lg ${
              isJazz 
                ? 'border-slate-800 hover:border-rose-500/40 hover:shadow-rose-500/5' 
                : 'border-slate-800 hover:border-amber-500/40 hover:shadow-amber-500/5'
            }`
          : `bg-white shadow-sm hover:shadow-xl hover:-translate-y-0.5 border ${
              isJazz
                ? 'border-slate-200/90 hover:border-rose-400/60 shadow-slate-200/40'
                : 'border-slate-200/90 hover:border-amber-400/60 shadow-slate-200/40'
            }`
      }`}
    >
      {/* Top Banner & Header */}
      <div className="p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl p-1 border flex items-center justify-center flex-shrink-0 transition-transform duration-300 group-hover:scale-105 ${
              isDark
                ? (isJazz ? 'bg-slate-950 border-rose-900/50 group-hover:border-rose-500/50' : 'bg-slate-950 border-amber-900/50 group-hover:border-amber-500/50')
                : (isJazz ? 'bg-rose-50/50 border-rose-200 group-hover:border-rose-400 shadow-2xs' : 'bg-amber-50/50 border-amber-200 group-hover:border-amber-400 shadow-2xs')
            }`}>
              <img 
                src={pkg.logo} 
                alt={pkg.title} 
                loading="lazy"
                className="w-full h-full object-contain rounded-lg" 
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  isDark
                    ? (isJazz ? 'bg-rose-500/15 text-rose-400 border border-rose-500/30' : 'bg-amber-500/15 text-amber-400 border border-amber-500/30')
                    : (isJazz ? 'bg-rose-100 text-rose-700 border border-rose-200' : 'bg-amber-100 text-amber-800 border border-amber-200')
                }`}>
                  {pkg.network}
                </span>
                <span className={`text-[10px] font-semibold ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {isWeekly ? '7 Days' : '30 Days'}
                </span>
              </div>
              <h3 className={`text-sm font-bold transition-colors line-clamp-1 ${
                isDark 
                  ? 'text-white group-hover:text-amber-200' 
                  : 'text-slate-900 group-hover:text-amber-700'
              }`}>
                {pkg.title}
              </h3>
            </div>
          </div>

          {/* Price Tag */}
          <div className="text-right flex-shrink-0">
            <div className="flex items-baseline justify-end gap-1">
              <span className={`text-[10px] font-bold uppercase ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Rs</span>
              <span className={`text-xl sm:text-2xl font-black tracking-tight ${
                isDark
                  ? (isJazz ? 'text-rose-400' : 'text-amber-400')
                  : (isJazz ? 'text-red-600' : 'text-orange-600')
              }`}>
                {pkg.price}
              </span>
            </div>
            <span className={`text-[9px] font-medium block -mt-0.5 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Incl. Tax</span>
          </div>
        </div>

        {/* Feature List */}
        <div className={`rounded-xl p-3 mb-4 border transition-colors ${
          isDark ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50/90 border-slate-200/80'
        }`}>
          <ul className="space-y-1.5">
            {pkg.features.map((feature, idx) => (
              <FeatureItem key={idx} text={feature} network={pkg.network} isDark={isDark} />
            ))}
          </ul>
        </div>

        {/* USSD Code Inline Badge with Quick Copy */}
        <div className={`flex items-center justify-between gap-2 p-2 rounded-xl border mb-4 text-[11px] transition-colors ${
          isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100/90 border-slate-200'
        }`}>
          <div className="flex items-center gap-1.5 min-w-0">
            <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${
              isDark ? 'text-slate-500 bg-slate-900 border-slate-800' : 'text-slate-600 bg-white border-slate-200 shadow-2xs'
            }`}>
              Code
            </span>
            <code className={`font-mono font-bold truncate ${
              isDark ? 'text-emerald-400' : 'text-emerald-700'
            }`}>
              {pkg.ussd}
            </code>
          </div>
          <button
            type="button"
            onClick={() => onQuickCopy(pkg.ussd)}
            className={`flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold rounded-lg border shadow-xs transition-all active:scale-95 ${
              isDark
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300'
            }`}
            title="Copy code template"
          >
            {isCopied ? (
              <>
                <Check className="w-3 h-3 text-emerald-500" />
                <span className="text-emerald-500">Copied</span>
              </>
            ) : (
              <>
                <Copy className={`w-3 h-3 ${isDark ? 'text-slate-400' : 'text-slate-500'}`} />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Action CTA Button */}
      <div className={`p-3 sm:p-4 border-t transition-colors ${
        isDark ? 'bg-slate-950/40 border-slate-800/80' : 'bg-slate-50/70 border-slate-100'
      }`}>
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={() => onActivate(pkg)}
          className={`w-full py-3 rounded-xl text-xs font-bold transition-all duration-200 flex items-center justify-center gap-2 ${
            isJazz 
              ? 'bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:brightness-110 text-white shadow-lg shadow-rose-600/20' 
              : 'bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:brightness-110 text-slate-950 shadow-lg shadow-amber-500/20'
          }`}
        >
          <span>Activate Package</span>
          <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </motion.button>
      </div>
    </motion.div>
  );
});
PackageCard.displayName = 'PackageCard';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [network, setNetwork] = useState<Network>('ufone');
  const [category, setCategory] = useState<Category>('weekly');
  const [activeFilterTag, setActiveFilterTag] = useState<FilterTag>('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Theme state: 'dark' (default luxury titanium) or 'light' (clean executive pearl)
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('amz_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  const isDark = theme === 'dark';

  // Synchronize theme with HTML document class & localStorage
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('amz_theme', theme);
    }
    const metaThemeColor = document.querySelector('meta[name="theme-color"]');
    if (metaThemeColor) {
      metaThemeColor.setAttribute('content', isDark ? '#0B1120' : '#FFFFFF');
    }
  }, [isDark, theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Modals state
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [showEasyload, setShowEasyload] = useState(false);
  const [showReverse, setShowReverse] = useState(false);
  const [showContact, setShowContact] = useState(false);

  // Form states
  const [phoneNumber, setPhoneNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [tid, setTid] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const isJazz = network === 'jazz';

  useEffect(() => {
    if (toastMsg) {
      const timer = setTimeout(() => setToastMsg(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [toastMsg]);

  useEffect(() => {
    if (copiedCode) {
      const timer = setTimeout(() => setCopiedCode(null), 2000);
      return () => clearTimeout(timer);
    }
  }, [copiedCode]);

  // Execute or Dial USSD
  const executeUssd = (ussdCode: string) => {
    if (!ussdCode) return;
    
    // Copy clean USSD to clipboard
    if (navigator.clipboard) {
      navigator.clipboard.writeText(ussdCode).catch(() => {});
    }
    setToastMsg(`Dialing & Copied: ${ussdCode}`);

    // Encode '#' as '%23' for 'tel:' links so browser parser does not strip '#'
    const formattedTel = `tel:${ussdCode.replace(/#/g, '%23')}`;
    window.location.href = formattedTel;
  };

  const handleQuickCopy = (code: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(code).catch(() => {});
    }
    setCopiedCode(code);
    setToastMsg(`Code copied: ${code}`);
  };

  // Filtered packages with tags and search
  const filteredPackages = useMemo(() => {
    return PACKAGES.filter(pkg => {
      if (pkg.network !== network) return false;
      if (pkg.category !== category) return false;

      // Filter by tag
      if (activeFilterTag !== 'all') {
        const text = (pkg.title + ' ' + pkg.features.join(' ')).toLowerCase();
        if (activeFilterTag === 'gaming' && !/gaming|pubg|freefire/i.test(text)) return false;
        if (activeFilterTag === 'social' && !/whatsapp|tiktok|snapchat|social/i.test(text)) return false;
        if (activeFilterTag === 'data' && !/gb|internet|data/i.test(text)) return false;
        if (activeFilterTag === 'calls' && !/minute|call|awaz|u2u|off-net/i.test(text)) return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = pkg.title.toLowerCase().includes(q);
        const matchesFeatures = pkg.features.some(f => f.toLowerCase().includes(q));
        const matchesPrice = pkg.price.toString().includes(q);
        return matchesTitle || matchesFeatures || matchesPrice;
      }

      return true;
    }).sort((a, b) => a.price - b.price);
  }, [network, category, activeFilterTag, searchQuery]);

  // Count metrics
  const weeklyCount = useMemo(() => PACKAGES.filter(p => p.network === network && p.category === 'weekly').length, [network]);
  const monthlyCount = useMemo(() => PACKAGES.filter(p => p.network === network && p.category === 'monthly').length, [network]);

  const handleActivate = (pkg: Package) => {
    setSelectedPackage(pkg);
    setPhoneNumber('');
  };

  const submitActivation = () => {
    if (!phoneNumber || phoneNumber.length !== 11 || !phoneNumber.startsWith('03')) {
      alert('Please enter a valid 11-digit mobile number (e.g. 03001234567)');
      return;
    }
    const ussd = selectedPackage?.ussd.replace('number', phoneNumber);
    if (ussd) {
      executeUssd(ussd);
    }
    setSelectedPackage(null);
    setPhoneNumber('');
  };

  const closeModal = () => {
    setSelectedPackage(null);
    setShowEasyload(false);
    setShowReverse(false);
    setShowContact(false);
    setPhoneNumber('');
    setAmount('');
    setTid('');
  };

  const submitEasyload = () => {
    if (!phoneNumber || phoneNumber.length !== 11 || !phoneNumber.startsWith('03')) {
      alert('Please enter a valid 11-digit mobile number (03XXXXXXXXX)');
      return;
    }
    if (!amount || parseInt(amount) <= 0) {
      alert('Please enter a valid amount');
      return;
    }
    // USSD Code based on network:
    // Jazz: *510*1*number*Rs#
    // Ufone: *777*number*Rs*111111#
    const ussd = isJazz 
      ? `*510*1*${phoneNumber}*${amount}#`
      : `*777*${phoneNumber}*${amount}*111111#`;
    executeUssd(ussd);
    setShowEasyload(false);
  };

  const submitReverse = () => {
    if (isJazz) {
      // Jazz Load Reversal: *510*4*Trx id#
      if (!tid || tid.trim().length < 3) {
        alert('Please enter a valid Transaction ID (TID)');
        return;
      }
      const ussd = `*510*4*${tid.trim()}#`;
      executeUssd(ussd);
      setShowReverse(false);
      return;
    }

    // Ufone Load Reversal: *964*number*10*3*tid#
    if (!phoneNumber || phoneNumber.length !== 11 || !phoneNumber.startsWith('03')) {
      alert('Please enter a valid 11-digit number');
      return;
    }
    if (!tid || tid.trim().length < 3) {
      alert('Please enter a valid Transaction ID (TID)');
      return;
    }
    const ussd = `*964*${phoneNumber}*10*3*${tid.trim()}#`;
    executeUssd(ussd);
    setShowReverse(false);
  };

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
      isDark 
        ? 'bg-slate-950 text-slate-100 selection:bg-amber-500 selection:text-slate-950' 
        : 'bg-slate-100/90 text-slate-900 selection:bg-amber-500 selection:text-white'
    }`}>
      {/* Animated Splash Screen */}
      <AnimatePresence>
        {showSplash && <SplashScreen onComplete={() => setShowSplash(false)} />}
      </AnimatePresence>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div 
            initial={{ opacity: 0, y: -24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -24, scale: 0.95 }}
            className="fixed top-5 left-1/2 -translate-x-1/2 z-[200] bg-slate-900/95 backdrop-blur-md text-white text-xs font-bold px-4 py-3 rounded-full shadow-2xl flex items-center gap-2.5 border border-slate-700 max-w-[90vw]"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span className="truncate">{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Container */}
      <div className={`w-full max-w-4xl mx-auto flex-1 flex flex-col shadow-2xl relative transition-colors duration-200 ${
        isDark 
          ? 'bg-slate-900/30 border-x border-slate-800/80' 
          : 'bg-white border-x border-slate-200'
      }`}>
        
        {/* Professional Brand Header */}
        <header className={`relative p-4 sm:p-6 rounded-b-[2rem] shadow-xl overflow-hidden border-b transition-all duration-300 ${
          isDark
            ? 'bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border-slate-800/90'
            : 'bg-gradient-to-b from-white via-slate-50 to-slate-100/80 border-slate-200'
        }`}>
          
          {/* Subtle Atmospheric Accents */}
          <div className={`absolute top-0 right-0 -mr-20 -mt-20 w-72 h-72 rounded-full blur-3xl pointer-events-none transition-colors duration-700 ${
            isJazz 
              ? (isDark ? 'bg-rose-500/10' : 'bg-rose-500/5') 
              : (isDark ? 'bg-amber-500/10' : 'bg-amber-500/5')
          }`} />
          <div className={`absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 rounded-full blur-3xl pointer-events-none ${
            isDark ? 'bg-cyan-500/5' : 'bg-blue-500/5'
          }`} />

          {/* Top Bar: Brand, Install App, Theme Toggle & Support */}
          <div className="relative z-10 flex items-center justify-between gap-3 mb-5">
            <div className="flex items-center gap-3">
              {/* AMZ SHOP Brand Monogram Emblem */}
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500/20 via-orange-500/20 to-rose-500/20 p-[1.5px] shadow-lg shadow-amber-500/10 flex-shrink-0">
                <div className={`w-full h-full rounded-2xl flex flex-col items-center justify-center border transition-colors ${
                  isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-200 shadow-2xs'
                }`}>
                  <span className="font-display font-black text-xs tracking-wider bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
                    AMZ
                  </span>
                  <span className={`text-[7px] font-black uppercase -mt-0.5 ${
                    isDark ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    SHOP
                  </span>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h1 className={`text-base sm:text-lg font-black tracking-tight leading-none font-display ${
                    isDark ? 'text-white' : 'text-slate-900'
                  }`}>
                    AMZ SHOP
                  </h1>
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${
                    isDark 
                      ? 'bg-amber-500/15 text-amber-400 border-amber-500/25' 
                      : 'bg-amber-100 text-amber-800 border-amber-300 font-bold'
                  }`}>
                    PRO
                  </span>
                </div>
                <p className={`text-[10px] sm:text-xs font-medium mt-0.5 ${
                  isDark ? 'text-slate-400' : 'text-slate-500'
                }`}>
                  ASIF MOBILE ZONE • Bannu KPK
                </p>
              </div>
            </div>

            {/* Header Right Actions: Install App, Theme Toggle, Contact Support */}
            <div className="flex items-center gap-2">
              <PWAInstallButton isDark={isDark} />
              
              {/* Theme Toggle (Dark / Light Mode) */}
              <button
                onClick={toggleTheme}
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-95 border ${
                  isDark
                    ? 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/80 text-amber-400 hover:text-amber-300 shadow-xs'
                    : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 hover:text-indigo-600 shadow-xs'
                }`}
                title={isDark ? "Switch to Light Mode / لائٹ موڈ" : "Switch to Dark Mode / ڈارک موڈ"}
                aria-label="Toggle theme"
              >
                {isDark ? (
                  <Sun className="w-4 h-4 text-amber-400 transition-transform duration-300 hover:rotate-45" />
                ) : (
                  <Moon className="w-4 h-4 text-slate-700 transition-transform duration-300 hover:-rotate-12" />
                )}
              </button>

              {/* Contact Support Button */}
              <button
                onClick={() => setShowContact(true)}
                className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-95 border ${
                  isDark
                    ? 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/80 text-slate-300 hover:text-white shadow-xs'
                    : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700 hover:text-slate-900 shadow-xs'
                }`}
                title="Contact Support"
                aria-label="Contact Support"
              >
                <Phone className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Network Switcher Tabs (Professional Metallic Slider) */}
          <div className={`relative z-10 p-1.5 rounded-2xl border grid grid-cols-2 gap-1.5 transition-colors ${
            isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-200/70 border-slate-300/80'
          }`}>
            <button
              onClick={() => { setNetwork('ufone'); setActiveFilterTag('all'); }}
              className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all duration-300 ${
                network === 'ufone'
                  ? isDark
                    ? 'bg-slate-800 text-amber-400 border border-amber-500/30 shadow-md font-black scale-[1.01]'
                    : 'bg-white text-orange-600 border border-orange-300 shadow-xs font-black scale-[1.01]'
                  : isDark
                    ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${
                network === 'ufone' 
                  ? (isDark ? 'bg-amber-400 animate-pulse' : 'bg-orange-500 animate-pulse') 
                  : (isDark ? 'bg-slate-600' : 'bg-slate-400')
              }`} />
              <span>UFONE 4G</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                network === 'ufone' 
                  ? (isDark ? 'bg-amber-500/20 text-amber-300' : 'bg-orange-100 text-orange-700 font-bold') 
                  : (isDark ? 'bg-slate-900 text-slate-500' : 'bg-slate-300/80 text-slate-600')
              }`}>
                {PACKAGES.filter(p => p.network === 'ufone').length}
              </span>
            </button>

            <button
              onClick={() => { setNetwork('jazz'); setActiveFilterTag('all'); }}
              className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all duration-300 ${
                network === 'jazz'
                  ? isDark
                    ? 'bg-slate-800 text-rose-400 border border-rose-500/30 shadow-md font-black scale-[1.01]'
                    : 'bg-white text-red-600 border border-red-300 shadow-xs font-black scale-[1.01]'
                  : isDark
                    ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${
                network === 'jazz' 
                  ? (isDark ? 'bg-rose-400 animate-pulse' : 'bg-red-500 animate-pulse') 
                  : (isDark ? 'bg-slate-600' : 'bg-slate-400')
              }`} />
              <span>JAZZ 4G</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                network === 'jazz' 
                  ? (isDark ? 'bg-rose-500/20 text-rose-300' : 'bg-rose-100 text-rose-700 font-bold') 
                  : (isDark ? 'bg-slate-900 text-slate-500' : 'bg-slate-300/80 text-slate-600')
              }`}>
                {PACKAGES.filter(p => p.network === 'jazz').length}
              </span>
            </button>
          </div>
        </header>

        {/* Content Section */}
        <main className="flex-1 p-4 sm:p-6 space-y-5">
          
          {/* Quick Utility Bar for Ufone & Jazz (Easyload & Reversal) */}
          <div className="grid grid-cols-2 gap-3">
            {/* Easyload Action Card */}
            <motion.button 
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => { setShowEasyload(true); setPhoneNumber(''); setAmount(''); }}
              className={`p-3.5 rounded-2xl shadow-xs transition-all flex items-center gap-3 group text-left border ${
                isDark
                  ? `bg-slate-900 border-slate-800 ${isJazz ? 'hover:border-rose-500/40' : 'hover:border-amber-500/40'}`
                  : `bg-white border-slate-200 hover:shadow-md ${isJazz ? 'hover:border-rose-400' : 'hover:border-amber-400'}`
              }`}
            >
              <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 transition-all ${
                isJazz 
                  ? isDark
                    ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 group-hover:bg-rose-500 group-hover:text-white'
                    : 'bg-rose-50 border-rose-200 text-rose-600 group-hover:bg-rose-600 group-hover:text-white' 
                  : isDark
                    ? 'bg-amber-500/10 border-amber-500/20 text-amber-400 group-hover:bg-amber-500 group-hover:text-slate-950'
                    : 'bg-amber-50 border-amber-200 text-amber-700 group-hover:bg-amber-500 group-hover:text-slate-950'
              }`}>
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h4 className={`text-xs sm:text-sm font-bold transition-colors ${
                  isDark ? 'text-white' : 'text-slate-900'
                } ${
                  isJazz ? 'group-hover:text-rose-500' : 'group-hover:text-amber-600'
                }`}>
                  {isJazz ? 'Jazz Easyload' : 'Send Easyload'}
                </h4>
                <p className={`text-[10px] font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {isJazz ? '*510*1* Load' : '*777* Load'}
                </p>
              </div>
            </motion.button>

            {/* Load Reversal Action Card */}
            <motion.button 
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => { setShowReverse(true); setTid(''); setPhoneNumber(''); }}
              className={`p-3.5 rounded-2xl shadow-xs transition-all flex items-center gap-3 group text-left border ${
                isDark
                  ? `bg-slate-900 border-slate-800 ${isJazz ? 'hover:border-rose-500/40' : 'hover:border-indigo-500/40'}`
                  : `bg-white border-slate-200 hover:shadow-md ${isJazz ? 'hover:border-rose-400' : 'hover:border-indigo-400'}`
              }`}
            >
              <div className={`w-10 h-10 rounded-xl border flex items-center justify-center flex-shrink-0 transition-all ${
                isJazz 
                  ? isDark
                    ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 group-hover:bg-rose-500 group-hover:text-white'
                    : 'bg-rose-50 border-rose-200 text-rose-600 group-hover:bg-rose-600 group-hover:text-white'
                  : isDark
                    ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white'
                    : 'bg-indigo-50 border-indigo-200 text-indigo-700 group-hover:bg-indigo-600 group-hover:text-white'
              }`}>
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <h4 className={`text-xs sm:text-sm font-bold transition-colors ${
                  isDark ? 'text-white' : 'text-slate-900'
                } ${
                  isJazz ? 'group-hover:text-rose-500' : 'group-hover:text-indigo-600'
                }`}>
                  {isJazz ? 'Jazz Reverse' : 'Load Reverse'}
                </h4>
                <p className={`text-[10px] font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  {isJazz ? '*510*4* Reversal' : '*964* Reversal'}
                </p>
              </div>
            </motion.button>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${
              isDark ? 'text-slate-500' : 'text-slate-400'
            }`} />
            <input 
              type="text" 
              placeholder={`Search ${network.toUpperCase()} by package name, GB, minutes or price...`}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-11 pr-10 py-3 rounded-2xl border text-xs sm:text-sm transition-all focus:outline-none ${
                isDark
                  ? 'bg-slate-900 text-white border-slate-800 placeholder:text-slate-500 focus:border-slate-600 focus:ring-1 focus:ring-slate-600 shadow-inner'
                  : 'bg-white text-slate-900 border-slate-200 placeholder:text-slate-400 focus:border-slate-400 focus:ring-1 focus:ring-slate-200 shadow-xs'
              }`}
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className={`absolute right-3 top-1/2 -translate-y-1/2 p-1 ${
                  isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Toggle: Weekly vs Monthly */}
          <div className={`flex items-center justify-between gap-2 border-b pb-3 transition-colors ${
            isDark ? 'border-slate-800/80' : 'border-slate-200'
          }`}>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setCategory('weekly')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  category === 'weekly' 
                    ? isJazz 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-amber-500 text-slate-950 font-black shadow-md'
                    : isDark
                      ? 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 shadow-2xs'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Weekly Bundles</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  category === 'weekly' 
                    ? (isJazz ? 'bg-white/20 text-white' : 'bg-slate-950/20 text-slate-950 font-black') 
                    : (isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500')
                }`}>
                  {weeklyCount}
                </span>
              </button>

              <button 
                onClick={() => setCategory('monthly')}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  category === 'monthly' 
                    ? isJazz 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-amber-500 text-slate-950 font-black shadow-md'
                    : isDark
                      ? 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                      : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 shadow-2xs'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Monthly Bundles</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  category === 'monthly' 
                    ? (isJazz ? 'bg-white/20 text-white' : 'bg-slate-950/20 text-slate-950 font-black') 
                    : (isDark ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500')
                }`}>
                  {monthlyCount}
                </span>
              </button>
            </div>

            <div className={`hidden sm:flex items-center gap-1.5 text-xs font-medium ${
              isDark ? 'text-slate-400' : 'text-slate-500'
            }`}>
              <span className={`font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{filteredPackages.length}</span> packages active
            </div>
          </div>

          {/* Quick Filter Tags (Gaming, Social, Data, Calls) */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            {[
              { id: 'all', label: 'All Packages', icon: Sparkles },
              { id: 'data', label: 'Internet Data', icon: Globe },
              { id: 'social', label: 'Social & WA', icon: MessageCircle },
              { id: 'gaming', label: 'Gaming', icon: Gamepad2 },
              { id: 'calls', label: 'Calls & Mins', icon: Phone },
            ].map(tag => {
              const Icon = tag.icon;
              const isActive = activeFilterTag === tag.id;
              return (
                <button
                  key={tag.id}
                  onClick={() => setActiveFilterTag(tag.id as FilterTag)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl whitespace-nowrap font-medium text-[11px] sm:text-xs transition-all border ${
                    isActive
                      ? isDark
                        ? isJazz
                          ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                          : 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                        : isJazz
                          ? 'bg-rose-50 text-rose-800 border-rose-300 font-bold shadow-2xs'
                          : 'bg-amber-50 text-amber-800 border-amber-300 font-bold shadow-2xs'
                      : isDark
                        ? 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                        : 'bg-white text-slate-600 border-slate-200 hover:text-slate-900 hover:border-slate-300 shadow-2xs'
                  }`}
                >
                  <Icon className="w-3 h-3" />
                  <span>{tag.label}</span>
                </button>
              );
            })}
          </div>

          {/* Package Grid (Responsive: 1 col on mobile, 2 cols on tablet/desktop) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <AnimatePresence mode="popLayout">
              {filteredPackages.map((pkg) => (
                <PackageCard 
                  key={pkg.id} 
                  pkg={pkg} 
                  onActivate={handleActivate} 
                  onQuickCopy={handleQuickCopy}
                  isCopied={copiedCode === pkg.ussd}
                  isDark={isDark}
                />
              ))}
            </AnimatePresence>
          </div>

          {/* Empty State */}
          {filteredPackages.length === 0 && (
            <div className={`text-center py-16 px-4 rounded-3xl border transition-colors ${
              isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 ${
                isDark ? 'bg-slate-800 text-slate-500' : 'bg-slate-200 text-slate-500'
              }`}>
                <Info className="w-7 h-7" />
              </div>
              <h3 className={`text-sm font-bold mb-1 ${isDark ? 'text-white' : 'text-slate-900'}`}>No packages found</h3>
              <p className={`text-xs mb-4 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Try clearing search or choosing another filter category.</p>
              <button 
                onClick={() => { setSearchQuery(''); setActiveFilterTag('all'); }}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                  isDark 
                    ? 'bg-slate-800 text-white hover:bg-slate-700' 
                    : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                Reset Filters
              </button>
            </div>
          )}

          {/* Footer Info & Developer Credits */}
          <footer className={`pt-6 pb-20 border-t text-center space-y-2 transition-colors ${
            isDark ? 'border-slate-800/80' : 'border-slate-200'
          }`}>
            <div className={`flex items-center justify-center gap-2 text-xs font-bold ${
              isDark ? 'text-slate-300' : 'text-slate-700'
            }`}>
              <span>AMZ SHOP</span>
              <span className="text-slate-400">•</span>
              <span>ASIF MOBILE ZONE</span>
              <span className="text-slate-400">•</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-mono">+92 333 3808084</span>
            </div>
            <p className={`text-[11px] ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>
              AMZ SHOP Portal • Instant USSD activation & Easyload for retail & customers.
            </p>
          </footer>
        </main>

        {/* Floating Quick Action Bottom Bar */}
        <nav className={`fixed bottom-0 left-0 right-0 max-w-4xl mx-auto backdrop-blur-xl border-t p-2 z-40 transition-colors ${
          isDark 
            ? 'bg-slate-950/90 border-slate-800/90 text-slate-400' 
            : 'bg-white/95 border-slate-200 text-slate-600 shadow-lg'
        }`}>
          <div className="grid grid-cols-4 gap-1 text-center">
            <button 
              onClick={() => { setCategory('weekly'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className={`py-1.5 rounded-xl flex flex-col items-center gap-1 transition-all ${
                category === 'weekly' 
                  ? (isJazz ? 'text-rose-500 font-bold' : (isDark ? 'text-amber-400 font-bold' : 'text-orange-600 font-bold')) 
                  : (isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900')
              }`}
            >
              <Zap className="w-4 h-4" />
              <span className="text-[10px] font-bold">Weekly</span>
            </button>

            <button 
              onClick={() => { setCategory('monthly'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className={`py-1.5 rounded-xl flex flex-col items-center gap-1 transition-all ${
                category === 'monthly' 
                  ? (isJazz ? 'text-rose-500 font-bold' : (isDark ? 'text-amber-400 font-bold' : 'text-orange-600 font-bold')) 
                  : (isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900')
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span className="text-[10px] font-bold">Monthly</span>
            </button>

            <button 
              onClick={() => {
                setShowEasyload(true);
                setPhoneNumber('');
                setAmount('');
              }}
              className={`py-1.5 rounded-xl flex flex-col items-center gap-1 transition-all ${
                isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <BadgePercent className="w-4 h-4" />
              <span className="text-[10px] font-bold">Easyload</span>
            </button>

            <button 
              onClick={() => setShowContact(true)}
              className={`py-1.5 rounded-xl flex flex-col items-center gap-1 transition-all ${
                isDark ? 'text-slate-400 hover:text-white' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Phone className="w-4 h-4" />
              <span className="text-[10px] font-bold">Contact</span>
            </button>
          </div>
        </nav>
      </div>

      {/* MODALS */}
      <AnimatePresence>
        {(selectedPackage || showEasyload || showReverse || showContact) && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={`fixed inset-0 z-[150] flex items-center justify-center p-4 overflow-y-auto ${
              isDark ? 'bg-black/80 backdrop-blur-sm' : 'bg-slate-900/60 backdrop-blur-xs'
            }`}
            onClick={closeModal}
          >
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 16 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 16 }}
              transition={{ duration: 0.2 }}
              className={`w-full max-w-sm rounded-3xl p-5 shadow-2xl relative border ${
                isDark ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-200 text-slate-900'
              }`}
              onClick={e => e.stopPropagation()}
            >
              <button 
                onClick={closeModal}
                className={`absolute right-4 top-4 p-1.5 rounded-full transition ${
                  isDark ? 'bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                <X className="w-4 h-4" />
              </button>

              {/* PACKAGE ACTIVATION MODAL */}
              {selectedPackage && (
                <div>
                  <div className="flex items-center gap-3 mb-4 pr-6">
                    <div className={`w-12 h-12 rounded-2xl p-1 border flex items-center justify-center flex-shrink-0 ${
                      isDark ? 'bg-slate-950 border-slate-700' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <img src={selectedPackage.logo} alt={selectedPackage.title} className="w-full h-full object-contain rounded-xl" />
                    </div>
                    <div>
                      <div className={`text-[10px] font-bold uppercase tracking-wider ${
                        isDark ? 'text-slate-400' : 'text-slate-500'
                      }`}>
                        {selectedPackage.network} • Rs {selectedPackage.price}
                      </div>
                      <h2 className={`text-sm sm:text-base font-bold leading-tight ${
                        isDark ? 'text-white' : 'text-slate-900'
                      }`}>
                        {selectedPackage.title}
                      </h2>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className={`text-[10px] font-bold uppercase tracking-wider mb-1 block ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}>
                        Customer Mobile Number
                      </label>
                      <input 
                        type="tel" 
                        placeholder="03XXXXXXXXX"
                        maxLength={11}
                        autoFocus
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                        className={`w-full px-4 py-3 rounded-xl border font-mono text-base tracking-widest focus:outline-none transition-colors ${
                          isDark 
                            ? 'bg-slate-950 text-white border-slate-700 focus:border-amber-500' 
                            : 'bg-slate-50 text-slate-900 border-slate-300 focus:border-amber-500 focus:bg-white'
                        }`}
                      />
                      <span className={`text-[10px] mt-1 block ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                        Enter 11 digits starting with 03 (e.g. 03001234567)
                      </span>
                    </div>

                    {/* Live Dial Code Preview */}
                    <div className={`p-3 rounded-xl border flex items-center justify-between gap-2 transition-colors ${
                      isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
                    }`}>
                      <div className="min-w-0">
                        <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                          isDark ? 'text-slate-500' : 'text-slate-500'
                        }`}>
                          Generated USSD Code
                        </span>
                        <span className={`text-sm font-mono font-bold truncate block ${
                          isDark ? 'text-emerald-400' : 'text-emerald-700'
                        }`}>
                          {selectedPackage.ussd.replace('number', phoneNumber || '03XXXXXXXXX')}
                        </span>
                      </div>
                      <button 
                        type="button"
                        onClick={() => {
                          const code = selectedPackage.ussd.replace('number', phoneNumber || '03XXXXXXXXX');
                          handleQuickCopy(code);
                        }}
                        className={`px-2.5 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1.5 flex-shrink-0 transition active:scale-95 ${
                          isDark 
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700' 
                            : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300 shadow-2xs'
                        }`}
                      >
                        <Copy className={`w-3.5 h-3.5 ${isDark ? 'text-slate-300' : 'text-slate-600'}`} />
                        <span>Copy</span>
                      </button>
                    </div>

                    <button 
                      onClick={submitActivation}
                      className={`w-full py-3.5 rounded-xl font-bold text-sm shadow-xl flex items-center justify-center gap-2 transition-all ${
                        selectedPackage.network === 'jazz'
                          ? 'bg-gradient-to-r from-rose-600 to-red-700 text-white shadow-rose-600/30 hover:brightness-110'
                          : 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 font-black shadow-amber-500/30 hover:brightness-110'
                      }`}
                    >
                      <Phone className="w-4 h-4" />
                      <span>Dial Now in Phone</span>
                    </button>
                  </div>
                </div>
              )}

              {/* EASYLOAD MODAL */}
              {showEasyload && (
                <div>
                  <div className="flex items-center gap-3 mb-4 pr-6">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      isJazz 
                        ? (isDark ? 'bg-rose-500/20 text-rose-400' : 'bg-rose-100 text-rose-700')
                        : (isDark ? 'bg-amber-500/20 text-amber-400' : 'bg-amber-100 text-amber-700')
                    }`}>
                      <Zap className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className={`text-base font-bold leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                        {isJazz ? 'Send Jazz Easyload' : 'Send Ufone Easyload'}
                      </h2>
                      <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                        {isJazz ? 'Jazz Retailer Load (*510*1*)' : 'Ufone Instant Recharge (*777*)'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className={`text-[10px] font-bold uppercase tracking-wider mb-1 block ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}>
                        Mobile Number
                      </label>
                      <input 
                        type="tel" 
                        placeholder="03XXXXXXXXX"
                        maxLength={11}
                        autoFocus
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                        className={`w-full px-4 py-2.5 rounded-xl border focus:outline-none font-mono text-sm tracking-widest ${
                          isDark
                            ? `bg-slate-950 text-white border-slate-700 ${isJazz ? 'focus:border-rose-500' : 'focus:border-amber-500'}`
                            : `bg-slate-50 text-slate-900 border-slate-300 focus:bg-white ${isJazz ? 'focus:border-rose-500' : 'focus:border-amber-500'}`
                        }`}
                      />
                    </div>

                    <div>
                      <label className={`text-[10px] font-bold uppercase tracking-wider mb-1 block ${
                        isDark ? 'text-slate-400' : 'text-slate-600'
                      }`}>
                        Amount (PKR)
                      </label>
                      <input 
                        type="number" 
                        placeholder="e.g. 100"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))}
                        className={`w-full px-4 py-2.5 rounded-xl border focus:outline-none font-bold text-sm ${
                          isDark
                            ? `bg-slate-950 text-white border-slate-700 ${isJazz ? 'focus:border-rose-500' : 'focus:border-amber-500'}`
                            : `bg-slate-50 text-slate-900 border-slate-300 focus:bg-white ${isJazz ? 'focus:border-rose-500' : 'focus:border-amber-500'}`
                        }`}
                      />
                      {/* Presets */}
                      <div className="flex gap-2 mt-2">
                        {[100, 200, 300, 500, 1000].map(val => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setAmount(val.toString())}
                            className={`px-2 py-1 text-[10px] font-bold rounded-lg border active:scale-95 transition-all ${
                              isDark 
                                ? 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300' 
                                : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                            }`}
                          >
                            Rs {val}
                          </button>
                        ))}
                      </div>
                    </div>

                    {phoneNumber.length === 11 && amount && (
                      <div className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                        isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
                      }`}>
                        <div className="min-w-0">
                          <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                            isDark ? 'text-slate-500' : 'text-slate-500'
                          }`}>USSD Code</span>
                          <span className={`text-xs font-mono font-bold truncate block ${
                            isDark ? 'text-emerald-400' : 'text-emerald-700'
                          }`}>
                            {isJazz ? `*510*1*${phoneNumber}*${amount}#` : `*777*${phoneNumber}*${amount}*111111#`}
                          </span>
                        </div>
                        <button 
                          type="button"
                          onClick={() => handleQuickCopy(isJazz ? `*510*1*${phoneNumber}*${amount}#` : `*777*${phoneNumber}*${amount}*111111#`)}
                          className={`px-2.5 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1 active:scale-95 ${
                            isDark 
                              ? 'bg-slate-800 text-white border-slate-700' 
                              : 'bg-white text-slate-700 border-slate-300 shadow-2xs'
                          }`}
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </button>
                      </div>
                    )}

                    <button 
                      onClick={submitEasyload}
                      className={`w-full py-3.5 font-bold rounded-xl text-sm shadow-xl transition-all ${
                        isJazz 
                          ? 'bg-gradient-to-r from-rose-600 to-red-700 hover:brightness-110 text-white shadow-rose-600/30' 
                          : 'bg-gradient-to-r from-amber-500 to-orange-600 hover:brightness-110 text-slate-950 font-black shadow-amber-500/20'
                      }`}
                    >
                      {isJazz ? 'Send Jazz Load' : 'Send Ufone Load'}
                    </button>
                  </div>
                </div>
              )}

              {/* LOAD REVERSE MODAL */}
              {showReverse && (
                <div>
                  <div className="flex items-center gap-3 mb-4 pr-6">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      isJazz 
                        ? (isDark ? 'bg-rose-500/20 text-rose-400' : 'bg-rose-100 text-rose-700')
                        : (isDark ? 'bg-indigo-500/20 text-indigo-400' : 'bg-indigo-100 text-indigo-700')
                    }`}>
                      <RotateCcw className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className={`text-base font-bold leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                        {isJazz ? 'Jazz Load Reverse' : 'Ufone Load Reverse'}
                      </h2>
                      <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                        {isJazz ? 'Jazz Reversal (*510*4*Trx id#)' : 'Ufone Reversal (*964*)'}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {!isJazz && (
                      <div>
                        <label className={`text-[10px] font-bold uppercase tracking-wider mb-1 block ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          Wrong Number Loaded
                        </label>
                        <input 
                          type="tel" 
                          placeholder="03XXXXXXXXX"
                          maxLength={11}
                          autoFocus
                          value={phoneNumber}
                          onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
                          className={`w-full px-4 py-2.5 rounded-xl border focus:outline-none font-mono text-sm tracking-widest ${
                            isDark 
                              ? 'bg-slate-950 text-white border-slate-700 focus:border-indigo-500' 
                              : 'bg-slate-50 text-slate-900 border-slate-300 focus:bg-white focus:border-indigo-500'
                          }`}
                        />
                      </div>
                    )}

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className={`text-[10px] font-bold uppercase tracking-wider block ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          Transaction ID (Trx ID)
                        </label>
                        <span className={`text-[9px] font-mono ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>
                          {tid.length > 0 ? `${tid.length} digits` : 'Flexible (11 to 20+ digits)'}
                        </span>
                      </div>
                      <input 
                        type="text" 
                        placeholder="Enter Trx ID (e.g. 11, 16, 20 digits...)"
                        maxLength={32}
                        autoFocus={isJazz}
                        value={tid}
                        onChange={(e) => setTid(e.target.value.trim())}
                        className={`w-full px-4 py-2.5 rounded-xl border focus:outline-none font-mono text-sm tracking-wider ${
                          isDark
                            ? `bg-slate-950 text-white border-slate-700 ${isJazz ? 'focus:border-rose-500' : 'focus:border-indigo-500'}`
                            : `bg-slate-50 text-slate-900 border-slate-300 focus:bg-white ${isJazz ? 'focus:border-rose-500' : 'focus:border-indigo-500'}`
                        }`}
                      />
                      <span className={`text-[10px] mt-1 block ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                        Jitne marzi digits hon (11 se 20+ digits tak allow hai)
                      </span>
                    </div>

                    {((isJazz && tid.length >= 3) || (!isJazz && phoneNumber.length === 11 && tid.length >= 3)) && (
                      <div className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                        isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
                      }`}>
                        <div className="min-w-0">
                          <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                            isDark ? 'text-slate-500' : 'text-slate-500'
                          }`}>USSD Code</span>
                          <span className={`text-xs font-mono font-bold truncate block ${
                            isDark ? 'text-emerald-400' : 'text-emerald-700'
                          }`}>
                            {isJazz ? `*510*4*${tid}#` : `*964*${phoneNumber}*10*3*${tid}#`}
                          </span>
                        </div>
                        <button 
                          type="button"
                          onClick={() => handleQuickCopy(isJazz ? `*510*4*${tid}#` : `*964*${phoneNumber}*10*3*${tid}#`)}
                          className={`px-2.5 py-1.5 text-xs font-bold rounded-lg border flex items-center gap-1 active:scale-95 ${
                            isDark 
                              ? 'bg-slate-800 text-white border-slate-700' 
                              : 'bg-white text-slate-700 border-slate-300 shadow-2xs'
                          }`}
                        >
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </button>
                      </div>
                    )}

                    <button 
                      onClick={submitReverse}
                      className={`w-full py-3.5 font-bold rounded-xl text-sm shadow-xl transition-all ${
                        isJazz 
                          ? 'bg-gradient-to-r from-rose-600 to-red-700 hover:brightness-110 text-white shadow-rose-600/30' 
                          : 'bg-gradient-to-r from-indigo-600 to-indigo-700 hover:brightness-110 text-white shadow-indigo-600/30'
                      }`}
                    >
                      {isJazz ? 'Process Jazz Reversal' : 'Process Ufone Reversal'}
                    </button>
                  </div>
                </div>
              )}

              {/* CONTACT MODAL */}
              {showContact && (
                <div>
                  <div className="flex items-center gap-3 mb-4 pr-6">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${
                      isDark ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-100 text-emerald-700'
                    }`}>
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className={`text-base font-bold leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                        AMZ SHOP Support
                      </h2>
                      <p className={`text-xs ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>ASIF MOBILE ZONE</p>
                    </div>
                  </div>

                  <div className="space-y-2.5">
                    <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
                      isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center ${
                        isDark 
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                          : 'bg-emerald-100 border-emerald-200 text-emerald-700'
                      }`}>
                        <MessageCircle className="w-4 h-4" />
                      </div>
                      <div className="flex-1">
                        <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                          isDark ? 'text-slate-400' : 'text-slate-500'
                        }`}>WhatsApp Direct</span>
                        <span className={`text-sm font-bold font-mono ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          +92 333 3808084
                        </span>
                      </div>
                      <button
                        onClick={() => {
                          if (navigator.clipboard) navigator.clipboard.writeText('+923333808084');
                          setToastMsg('WhatsApp number copied!');
                        }}
                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold border transition ${
                          isDark 
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700' 
                            : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300 shadow-2xs'
                        }`}
                      >
                        Copy
                      </button>
                    </div>

                    <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
                      isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center ${
                        isDark 
                          ? 'bg-blue-500/10 border-blue-500/20 text-blue-400' 
                          : 'bg-blue-100 border-blue-200 text-blue-700'
                      }`}>
                        <Globe className="w-4 h-4" />
                      </div>
                      <div>
                        <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                          isDark ? 'text-slate-400' : 'text-slate-500'
                        }`}>Shop Location</span>
                        <span className={`text-xs font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          KPK Bannu, Pakistan
                        </span>
                      </div>
                    </div>

                    <div className={`p-3 rounded-2xl border flex items-center gap-3 ${
                      isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'
                    }`}>
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center ${
                        isDark 
                          ? 'bg-purple-500/10 border-purple-500/20 text-purple-400' 
                          : 'bg-purple-100 border-purple-200 text-purple-700'
                      }`}>
                        <ShieldCheck className="w-4 h-4" />
                      </div>
                      <div>
                        <span className={`text-[9px] font-bold uppercase tracking-wider block ${
                          isDark ? 'text-slate-400' : 'text-slate-500'
                        }`}>Author & Proprietor</span>
                        <span className={`text-xs font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                          FAISAL MALIK • ASIF MOBILE
                        </span>
                      </div>
                    </div>

                    <a 
                      href="https://wa.me/923333808084"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all mt-4"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Chat on WhatsApp</span>
                    </a>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Offline Status Toast */}
      <OfflineIndicator />
    </div>
  );
}
