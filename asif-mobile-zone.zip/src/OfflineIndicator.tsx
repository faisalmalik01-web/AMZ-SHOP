import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  if (isOnline) return null;

  return (
    <div className="fixed bottom-16 left-4 right-4 max-w-md mx-auto z-50 flex items-center justify-center gap-2 rounded-xl bg-slate-900/90 backdrop-blur-md px-3 py-2 text-[11px] font-bold text-amber-300 border border-amber-500/30 shadow-2xl">
      <WifiOff className="w-3.5 h-3.5 animate-pulse text-amber-400" />
      <span>Offline Mode — All packages cached & ready</span>
    </div>
  );
};
