export interface Package {
  id: string;
  title: string;
  price: number;
  features: string[];
  ussd: string;
  logo: string;
  category: 'weekly' | 'monthly';
  network: 'ufone' | 'jazz';
}

export const PACKAGES: Package[] = [
  // UFONE WEEKLY
  {
    id: 'u-w-1',
    title: 'TikTok Offer',
    price: 120,
    features: ['4GB Data Only For TikTok', '7 Days Validity', 'Unlimited TikTok Streaming'],
    ussd: '*1010*number#',
    logo: 'https://nestscale.com/wp-content/uploads/2023/07/Secondary-logo.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-2',
    title: 'FreeFire Offer',
    price: 60,
    features: ['1GB General Data', '4GB FreeFire Data', '7 Days Validity'],
    ussd: '*9090*2*2*number#',
    logo: 'https://cdn.mobygames.com/covers/9693864-garena-free-fire-iphone-front-cover.jpg',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-3',
    title: 'PUBG Offer',
    price: 70,
    features: ['PUBG Mobile Data Package', '7 Days Validity', 'Optimized for Gaming'],
    ussd: '*9090*1*2*number#',
    logo: 'https://play-lh.googleusercontent.com/9Q5je4kYh5EVvDLJSp20Vr6fFZB6qWAF0EtXj37o2h8yzD6vuvwa4fph83q7uIHkMQ7O',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-upower-350',
    title: 'UPOWER Weekly',
    price: 350,
    features: ['4GB Data', '5000 u2u minutes', '100 off-net', '7 Days Validity'],
    ussd: '*4000*3*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-upower-400',
    title: 'UPOWER Weekly',
    price: 450,
    features: ['10GB Data', '5000 u2u minutes', '200 off-net', '7 Days Validity'],
    ussd: '*4000*2*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-internet-500',
    title: 'Weekly Internet',
    price: 500,
    features: ['15GB Data', '5000 u2u minutes', '300 off-net', '7 Days Validity'],
    ussd: '*4000*1*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-internet-60gb',
    title: 'Weekly Internet 60GB',
    price: 600,
    features: ['60GB Data', '5000 u2u minutes', '600 off-net', '7 Days Validity'],
    ussd: '*4040*3*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-25gb-550',
    title: '25GB Weekly Offer',
    price: 550,
    features: ['25GB Data', '5000 u2u minutes', '250 Off-Net', '7 Days Validity'],
    ussd: '*4000*5*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-recharge-120',
    title: 'Super Recharge',
    price: 120,
    features: ['500MB Data', '20 Off-Net', '200 u2u', '2 Days Validity'],
    ussd: '*4000*7*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-10',
    title: '100GB + 5000 U2U + 300 Off-Net',
    price: 630,
    features: ['100GB High-Speed Data', '5000 U2U Minutes', '300 Off-Net Minutes', '7 Days Validity'],
    ussd: '*4040*2*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  {
    id: 'u-w-11',
    title: '150GB + 5000 U2U + 300 Off-Net',
    price: 680,
    features: ['150GB High-Speed Data', '5000 U2U Minutes', '300 Off-Net Minutes', '7 Days Validity'],
    ussd: '*4040*1*number#',
    logo: 'https://cdn.aptoide.com/imgs/d/6/2/d62ed5520d127c17e61f3e9056c38127_icon.png',
    category: 'weekly',
    network: 'ufone'
  },
  // UFONE MONTHLY
  {
    id: 'u-m-2',
    title: 'FreeFire Monthly Offer',
    price: 100,
    features: ['1GB General Data', '9GB FreeFire Data', '30 Days Validity'],
    ussd: '*9090*2*3*number#',
    logo: 'https://cdn.mobygames.com/covers/9693864-garena-free-fire-iphone-front-cover.jpg',
    category: 'monthly',
    network: 'ufone'
  },
  {
    id: 'u-m-3',
    title: 'PUBG Monthly Offer',
    price: 150,
    features: ['1GB General Data', '9GB PUBG Data', '30 Days Validity', 'Optimized for Gaming'],
    ussd: '*9090*1*3*number#',
    logo: 'https://play-lh.googleusercontent.com/9Q5je4kYh5EVvDLJSp20Vr6fFZB6qWAF0EtXj37o2h8yzD6vuvwa4fph83q7uIHkMQ7O',
    category: 'monthly',
    network: 'ufone'
  },
  {
    id: 'u-m-6',
    title: '25GB Social + 3000 u2u + 300 offNet',
    price: 800,
    features: ['25GB Data', '3000 u2u minutes', '300 Off-Net Minutes', '30 Days Validity'],
    ussd: '*964*number*3*1*1#',
    logo: 'https://cdn.shopify.com/app-store/listing_images/0dce682fb3602fe48c948f046351cae8/icon/CNjJrcKUyY8DEAE=.png',
    category: 'monthly',
    network: 'ufone'
  },
  {
    id: 'u-m-7',
    title: '10GB Data For WhatsApp Only',
    price: 300,
    features: ['10GB WhatsApp Data', '30 Days Validity', 'Unlimited WhatsApp Calls'],
    ussd: '*964*number*3*1*3#',
    logo: 'https://static.vecteezy.com/system/resources/thumbnails/016/716/455/small/whatsapp-for-business-icon-free-png.png',
    category: 'monthly',
    network: 'ufone'
  },
  {
    id: 'u-m-8',
    title: 'Mahana Awaz Offer',
    price: 650,
    features: ['4000 u2u minutes', '400 Off-Net Minutes', '30 Days Validity'],
    ussd: '*964*number*6*2*4#',
    logo: 'https://static.vecteezy.com/system/resources/thumbnails/014/441/078/small_2x/phone-call-icon-design-in-blue-circle-png.png',
    category: 'monthly',
    network: 'ufone'
  },
  {
    id: 'u-m-snapchat-80',
    title: 'SnapChat Offer',
    price: 90,
    features: ['6GB Snapchat Data', '30 Days Validity', 'Unlimited Snapchat Filters'],
    ussd: '*5550*5*number#',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfwxsLc9YL5hBf-McHnTn_2hpDT73_WMsecO-yRJwp3l-6yPpeS_-JFTQA&s=10',
    category: 'monthly',
    network: 'ufone'
  },

  // JAZZ WEEKLY
  {
    id: 'j-w-pubg-70',
    title: 'Weekly PUBG',
    price: 70,
    features: ['PUBG Data', '7 Days Validity'],
    ussd: '*964*number*3*2*2#',
    logo: 'https://play-lh.googleusercontent.com/9Q5je4kYh5EVvDLJSp20Vr6fFZB6qWAF0EtXj37o2h8yzD6vuvwa4fph83q7uIHkMQ7O',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-1',
    title: 'Weekly Super Card',
    price: 250,
    features: ['3GB Data + 10GB WhatsApp', '300 Jazz Minutes', '10 All Network Minutes', '7 Days Validity'],
    ussd: '*964*number*5*7*7#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-2',
    title: 'Weekly Mega Data',
    price: 300,
    features: ['5GB High-Speed Data', '1000 Jazz Minutes', '50 Off-Net Minutes', '7 Days Validity'],
    ussd: '*964*number*5*7*5#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-3',
    title: 'Weekly X Plus',
    price: 800,
    features: ['100B Data', '600 Off-Net', '2000 Jazz Minutes', '7 Days Validity'],
    ussd: '*964*number*1*2*1#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-4',
    title: 'Weekly Freedom',
    price: 750,
    features: ['50GB High-Speed Data', '1000 Jazz Minutes', '3300 All Network Minutes', '7 Days Validity'],
    ussd: '*964*number*1*2*2#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-5',
    title: 'Weekly Max',
    price: 700,
    features: ['30GB High-Speed Data', '1000 Jazz Minutes', '150 All Network Minutes', '7 Days Validity'],
    ussd: '*964*number*1*2*3#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-6',
    title: 'Weekly Star',
    price: 650,
    features: ['20GB Data', '1000 Jazz Minutes', '150 AllNet Minutes', '7 Days Validity'],
    ussd: '*964*number*1*2*4#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },
  {
    id: 'j-w-7',
    title: 'Weekly Woman Bundle',
    price: 250,
    features: ['12GB Data', '8 AM To 6 PM', '1000 Jazz Minutes', '7 Days Validity'],
    ussd: '*964*number*1*2*9#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'weekly',
    network: 'jazz'
  },

  // JAZZ MONTHLY
  {
    id: 'j-m-1',
    title: 'Monthly X',
    price: 3100,
    features: ['200GB Data', '3000 Jazz Minutes', '1000 All Network Minutes', '30 Days Validity'],
    ussd: '*964*number*1*1*1#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-2',
    title: 'Monthly Social',
    price: 1700,
    features: ['50GB Data TikTok Video & Social', '3000 Jazz Minutes', '300 All Network Minutes', '30 Days Validity'],
    ussd: '*964*number*3*1*2#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-3',
    title: 'Monthly Social Pack',
    price: 1500,
    features: ['30GB Social + TikTok', '100 Off-Net', '500 Jazz Minutes', '30 Days Validity'],
    ussd: '*964*number*3*1*3#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-4',
    title: 'Monthly Social',
    price: 1200,
    features: ['20GB Social + TikTok', '500 Jazz Minutes', '100 All Network Minutes', '30 Days Validity'],
    ussd: '*964*number*3*1*4#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-5',
    title: 'Monthly Ultra Social',
    price: 700,
    features: ['10GB YT & Social', '300 Jazz Minutes', '50 All Network Minutes', '30 Days Validity'],
    ussd: '*964*number*3*1*7#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-6',
    title: 'Monthly WhatsApp Offer',
    price: 550,
    features: ['10GB Social Data', '300 Jazz Minutes', '15 Off-Net Calls', '30 Days Validity'],
    ussd: '*964*number*3*1*8#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-7',
    title: 'Monthly Call',
    price: 900,
    features: ['2000 Jazz Minutes', '300 Off-Net', '30 Days Validity'],
    ussd: '*964*number*4*1*4#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  },
  {
    id: 'j-m-8',
    title: 'Monthly Gaming Pack',
    price: 500,
    features: ['Gaming Optimized Data', '1000 Jazz Minutes', '30 Days Validity'],
    ussd: '*964*number*4*1*5#',
    logo: 'https://crystalpng.com/wp-content/uploads/2024/11/jazz-logo.png',
    category: 'monthly',
    network: 'jazz'
  }
];
